# YILBAY Öğrenci Takip — v0.6.2

- OpenAI anahtarı Windows Credential Manager kaydından otomatik okunur.
- Hedef: `YILBAY-OPENAI-API-HOME`
- Kullanıcı: `YILBAY-DEVELOPMENT-HOME`
- Parola/API anahtarı yalnız bellekte kullanılır; log, rapor veya api_secrets.json içine kopyalanmaz.
- Öncelik: Windows Credential Manager → OPENAI_API_KEY → manuel ayar.
