# YILBAY Öğrenci Takip — v0.6.1

AI adaptif koçluk altyapısı:
- AI ve API Entegrasyonları menüsü aktif.
- Yeni öğrenci kaydında kayıt tarihi, kurs bitiş tarihi, haftalık çalışma günü, günlük süre ve AI otomatik plan parametreleri.
- OpenAI dönem planlama endpointi + deterministik fallback.
- Öğrenci seviyesine göre deterministik kaynak seçimi.
- PDF/görsel ödev Vision analizi.
- YouTube konu anlatım videosu araması.
- Gerçek OpenAI usage tokenlarından işlem bazlı maliyet hesabı.
- Aylık AI maliyet/bütçe sayacı.
- USD/TL maliyet kuru kullanıcı tarafından ayarlanabilir.
- API anahtarları yalnız runtime/api_secrets.json içinde; tarayıcıya veya teşhis raporuna yazılmaz.
