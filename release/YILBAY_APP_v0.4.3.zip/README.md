# YILBAY Öğrenci Takip — v0.4.3

- Öğrenci düzenleme ve silme
- Öğrenci bazında ders seçimi
- Her ders için öğrenci kaynak zorluk seviyesi
- Haftalık programda öğrenci seçimi
- Son konu sonucuna göre adaptif tekrar
- Öğrenci seviyesine uygun kaynak önceliklendirme
- v0.4.0 yerel verisini v0.4.3 depolamasına otomatik taşıma
