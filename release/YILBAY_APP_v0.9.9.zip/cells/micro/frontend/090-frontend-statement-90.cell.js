applyViewportProfile()
