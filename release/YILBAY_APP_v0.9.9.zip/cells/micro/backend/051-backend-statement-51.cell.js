installLaunchPreferences()
