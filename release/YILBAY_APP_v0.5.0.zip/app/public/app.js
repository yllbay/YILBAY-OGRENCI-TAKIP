const STORAGE="yilbay_mvp_050";
const PREV_STORAGE_045="yilbay_mvp_045";
const PREV_STORAGE="yilbay_mvp_044";
const LEGACY_043="yilbay_mvp_043";
const OLD_STORAGE="yilbay_mvp_040";
const seed={
 students:[{id:1,name:"Bilgehan Özdurak",grade:"12",target:"YKS",courses:["TYT Matematik","Problemler","Türkçe"],levels:{"TYT Matematik":"Orta","Problemler":"Orta-Zor","Türkçe":"Orta"}}],
 curriculum:{
   "TYT Matematik":{"Temel Matematik":["Temel Kavramlar","Bölme-Bölünebilme","Rasyonel Sayılar","1. Derece Denklemler","Basit Eşitsizlikler","Mutlak Değer"]},
   "Problemler":{"Problemler":["Sayı Problemleri","Kesir Problemleri","Yaş Problemleri"]},
   "Türkçe":{"Paragraf":["Paragrafta Konu","Paragrafta Başlık","Ana Düşünce"],"Dil Bilgisi":["Yazım Kuralları","Ses Bilgisi"]}
 },
 resources:[
  {id:1,type:"PDF",course:"TYT Matematik",topic:"Mutlak Değer",level:"Orta",title:"Mutlak Değer Ödev 01",url:""},
  {id:2,type:"PDF",course:"Problemler",topic:"Sayı Problemleri",level:"Orta-Zor",title:"Sayı Problemleri Ödev 01",url:""}
 ],
 exams:[
  {id:1,course:"TYT Matematik",topic:"Mutlak Değer",title:"Mutlak Değer Online Test",url:"https://example.com"}
 ],
 results:[
  {id:1,studentId:1,kind:"Ödev",course:"TYT Matematik",topic:"Mutlak Değer",score:58,date:"2026-08-25"},
  {id:2,studentId:1,kind:"Online Sınav",course:"TYT Matematik",topic:"Basit Eşitsizlikler",score:74,date:"2026-08-25"}
 ],
 threshold:70
};
let db=load(), view="dashboard";
function load(){try{
 const current=localStorage.getItem(STORAGE);
 if(current) return normalizeDb(JSON.parse(current));
 const p45=localStorage.getItem(PREV_STORAGE_045);
 if(p45){const migrated=normalizeDb(JSON.parse(p45));localStorage.setItem(STORAGE,JSON.stringify(migrated));return migrated;}
 const prev=localStorage.getItem(PREV_STORAGE);
 if(prev){const migrated=normalizeDb(JSON.parse(prev)); localStorage.setItem(STORAGE,JSON.stringify(migrated)); return migrated;}
 const legacy43=localStorage.getItem(LEGACY_043);
 if(legacy43){const migrated=normalizeDb(JSON.parse(legacy43)); localStorage.setItem(STORAGE,JSON.stringify(migrated)); return migrated;}
 const old=localStorage.getItem(OLD_STORAGE);
 if(old){const migrated=normalizeDb(JSON.parse(old)); localStorage.setItem(STORAGE,JSON.stringify(migrated)); return migrated;}
 return normalizeDb(structuredClone(seed))
}catch{return normalizeDb(structuredClone(seed))}}
function normalizeDb(x){
 x.assignments??=[];
 x.weeklyPlans??={};
 x.threshold??=70;
 return x
}
function save(){localStorage.setItem(STORAGE,JSON.stringify(db))}
const app=()=>document.getElementById("app");
const scoreClass=n=>n>=80?"good":n>=60?"mid":"low";
function initials(name=""){return name.split(/\s+/).filter(Boolean).slice(0,2).map(x=>x[0]).join("").toUpperCase()||"Ö"}
function tableWrap(html){return `<div class="table-wrap">${html}</div>`}
function emptyState(title,text){return `<div class="empty"><strong>${title}</strong>${text}</div>`}
function pageHead(title,desc,actions=""){return `<div class="page-head"><div class="page-title"><h1>${title}</h1><p>${desc}</p></div><div class="page-actions">${actions}</div></div>`}
function shell(content,active=view){app().innerHTML=`<div class="top"><div class="brand-wrap"><div class="brandmark">Y</div><div><div class="brand">YILBAY Öğrenci Takip</div><div class="brand-sub">Akademik Koçluk Yönetim Sistemi</div></div></div><div class="top-right"><span class="version">v0.5.0</span></div></div><div class="layout"><aside>
<div class="nav-section">Yönetim</div>${nav("dashboard","Genel Bakış",active)}${nav("students","Öğrenciler",active)}${nav("profile","Öğrenci Profili",active)}
<div class="nav-section">Akademik İçerik</div>${nav("curriculum","Ders ve Üniteler",active)}${nav("resources","Kaynak Havuzu",active)}${nav("exams","Online Sınavlar",active)}
<div class="nav-section">Operasyon</div>${nav("assignments","Atamalar",active)}${nav("results","Başarı Sonuçları",active)}${nav("program","Haftalık Program",active)}
</aside><main><div class="page">${content}</div></main></div>`}
function nav(k,t,a){return `<button class="nav ${a===k?"active":""}" onclick="go('${k}')">${t}</button>`}
window.go=k=>{view=k;render()}
function render(){({dashboard,students,profile,curriculum,resources,exams,assignments,results,program}[view]||dashboard)()}
function dashboard(){
 const low=db.results.filter(r=>r.score<db.threshold), pending=db.assignments.filter(a=>a.status!=="Tamamlandı");
 const avg=db.results.length?Math.round(db.results.reduce((n,r)=>n+r.score,0)/db.results.length):0;
 shell(`${pageHead("Genel Bakış","Öğrenciler, atamalar ve akademik performansın güncel özeti.")}
 <div class="grid">
 <div class="card kpi-card"><div class="kpi-label">Aktif öğrenci</div><div class="kpi">${db.students.length}</div><div class="kpi-foot">Koçluk takibindeki toplam öğrenci</div></div>
 <div class="card kpi-card"><div class="kpi-label">Bekleyen atama</div><div class="kpi">${pending.length}</div><div class="kpi-foot">Henüz tamamlanmamış görevler</div></div>
 <div class="card kpi-card"><div class="kpi-label">Tekrar sinyali</div><div class="kpi">${low.length}</div><div class="kpi-foot">%${db.threshold} eşiğinin altındaki sonuçlar</div></div>
 <div class="card kpi-card"><div class="kpi-label">Ortalama başarı</div><div class="kpi">%${avg}</div><div class="kpi-foot">Girilen tüm sonuçların ortalaması</div></div>
 <div class="card kpi-card"><div class="kpi-label">İçerik havuzu</div><div class="kpi">${db.resources.length+db.exams.length}</div><div class="kpi-foot">PDF kaynak + online sınav</div></div></div>
 <div class="section"><div class="section-head"><h2>Öncelikli tekrar konuları</h2><span class="muted">En düşük başarılar önce</span></div>
 ${low.length?`<div class="list">${low.slice().sort((a,b)=>a.score-b.score).slice(0,8).map(r=>`<div class="item item-row"><div><div class="cell-title">${studentName(r.studentId)}</div><div class="cell-sub">${r.course} · ${r.topic}</div></div><span class="badge low">%${r.score}</span></div>`).join("")}</div>`:emptyState("Tekrar gerektiren konu yok","Mevcut sonuçlar belirlenen başarı eşiğinin üzerinde.")}</div>`,'dashboard')
}
function studentName(id){return db.students.find(s=>s.id===id)?.name||"Bilinmeyen"}

function students(){
 const actions=`<button class="btn primary" onclick="studentModal()">+ Yeni Öğrenci</button>`;
 const rows=db.students.map(s=>`<tr><td><button class="navlink" onclick="openProfile(${s.id})">${s.name}</button><div class="cell-sub">${s.target||"Hedef belirtilmedi"}</div></td><td>${s.grade||"—"}</td><td>${(s.courses||[]).length}</td><td>${(s.courses||[]).map(c=>`<span class="badge neutral">${c}: ${s.levels?.[c]||"Orta"}</span>`).join(" ")||"—"}</td><td><div class="toolbar-group"><button class="btn ghost small" onclick="editStudent(${s.id})">Düzenle</button><button class="btn danger small" onclick="deleteStudent(${s.id})">Sil</button></div></td></tr>`).join("");
 shell(`${pageHead("Öğrenciler","Öğrenci profillerini, ders seçimlerini ve kaynak seviyelerini yönetin.",actions)}${db.students.length?tableWrap(`<table><thead><tr><th>Öğrenci</th><th>Sınıf</th><th>Ders Sayısı</th><th>Ders / Seviye</th><th>İşlemler</th></tr></thead><tbody>${rows}</tbody></table>`):emptyState("Henüz öğrenci yok","Yeni öğrenci ekleyerek koçluk takibini başlatın.")}`,'students')
}
function courseLevelFields(selected=[],levels={}){
 return Object.keys(db.curriculum).map(c=>`<div class="item"><label><input type="checkbox" class="coursecheck" value="${c}" ${selected.includes(c)?"checked":""}> <b>${c}</b></label>
 <select class="courselevel" data-course="${c}"><option>Başlangıç</option><option>Kolay</option><option ${levels[c]==="Orta"?"selected":""}>Orta</option><option ${levels[c]==="Orta-Zor"?"selected":""}>Orta-Zor</option><option ${levels[c]==="Zor"?"selected":""}>Zor</option><option ${levels[c]==="İleri"?"selected":""}>İleri</option></select></div>`).join("")
}
window.studentModal=()=>modal(`<h2>Yeni Öğrenci</h2><div class="formgrid">
<div class="field"><label>Ad Soyad</label><input id="sname"></div><div class="field"><label>Sınıf</label><input id="sgrade"></div>
<div class="field"><label>Hedef</label><input id="starget" value="YKS"></div></div>
<h3>Koçluk dersleri ve kaynak seviyesi</h3><div class="list">${courseLevelFields()}</div>
<div class="modal-actions"><button class="btn primary" onclick="addStudent()">Kaydet</button> <button class="btn ghost" onclick="closeModal()">İptal</button></div>`)
function readStudentCourses(){
 const courses=[...document.querySelectorAll(".coursecheck:checked")].map(x=>x.value),levels={};
 courses.forEach(c=>{levels[c]=document.querySelector(`.courselevel[data-course="${c}"]`)?.value||"Orta"});
 return {courses,levels}
}
window.addStudent=()=>{const name=q("sname").value.trim();if(!name)return alert("Ad soyad gerekli");const x=readStudentCourses();db.students.push({id:Date.now(),name,grade:q("sgrade").value,target:q("starget").value,courses:x.courses,levels:x.levels});save();closeModal();students()}
window.editStudent=id=>{const s=db.students.find(x=>x.id===id);if(!s)return;modal(`<h2>Öğrenci Düzenle</h2><input type="hidden" id="sid" value="${id}"><div class="formgrid"><div class="field"><label>Ad Soyad</label><input id="sname" value="${s.name}"></div><div class="field"><label>Sınıf</label><input id="sgrade" value="${s.grade||""}"></div><div class="field"><label>Hedef</label><input id="starget" value="${s.target||""}"></div></div><h3>Dersler / seviyeler</h3><div class="list">${courseLevelFields(s.courses||[],s.levels||{})}</div><div class="modal-actions"><button class="btn primary" onclick="saveStudentEdit()">Kaydet</button> <button class="btn ghost" onclick="closeModal()">İptal</button></div>`)}
window.saveStudentEdit=()=>{const id=Number(q("sid").value),s=db.students.find(x=>x.id===id);if(!s)return;const x=readStudentCourses();s.name=q("sname").value.trim();s.grade=q("sgrade").value;s.target=q("starget").value;s.courses=x.courses;s.levels=x.levels;save();closeModal();students()}
window.deleteStudent=id=>{if(!confirm("Öğrenci silinsin mi?"))return;db.students=db.students.filter(s=>s.id!==id);db.results=db.results.filter(r=>r.studentId!==id);save();students()}

let selectedProfileStudentId=null;
window.openProfile=id=>{selectedProfileStudentId=id;view="profile";profile()}
function profile(){
 if(!db.students.length){shell(`<h1>Öğrenci Profili</h1><div class="card">Önce öğrenci ekleyin.</div>`,"profile");return}
 if(!selectedProfileStudentId||!db.students.some(s=>s.id===selectedProfileStudentId))selectedProfileStudentId=db.students[0].id;
 const s=db.students.find(x=>x.id===selectedProfileStudentId);
 const rs=db.results.filter(r=>r.studentId===s.id).slice().sort((a,b)=>String(b.date).localeCompare(String(a.date)));
 const as=db.assignments.filter(a=>a.studentId===s.id).slice().sort((a,b)=>Number(b.id)-Number(a.id));
 const avg=rs.length?Math.round(rs.reduce((t,r)=>t+Number(r.score||0),0)/rs.length):0;
 const low=rs.filter(r=>r.score<db.threshold).length;
 shell(`<div class="toolbar"><h1>Öğrenci Profili</h1><select onchange="selectedProfileStudentId=Number(this.value);profile()">${db.students.map(x=>`<option value="${x.id}" ${x.id===s.id?"selected":""}>${x.name}</option>`).join("")}</select></div>
 <div class="grid">
  <div class="card"><div class="muted">Öğrenci</div><div class="kpi" style="font-size:20px">${s.name}</div><div>${s.grade}. sınıf · ${s.target||"—"}</div></div>
  <div class="card"><div class="muted">Ortalama başarı</div><div class="kpi">%${avg}</div></div>
  <div class="card"><div class="muted">Bekleyen atama</div><div class="kpi">${as.filter(a=>a.status!=="Tamamlandı").length}</div></div>
  <div class="card"><div class="muted">Tekrar sinyali</div><div class="kpi">${low}</div></div>
 </div>
 <h2>Dersler ve kaynak seviyeleri</h2><div class="list">${(s.courses||[]).map(c=>`<div class="item"><b>${c}</b> <span class="badge mid">${s.levels?.[c]||"Orta"}</span></div>`).join("")||"<div class='card'>Ders seçilmemiş.</div>"}</div>
 <h2>Son atamalar</h2><table><thead><tr><th>Tür</th><th>İçerik</th><th>Konu</th><th>Durum</th><th>Başarı</th></tr></thead><tbody>${as.slice(0,10).map(a=>`<tr><td>${a.kind}</td><td>${a.title}</td><td>${a.course} / ${a.topic}</td><td>${a.status}</td><td>${a.score!=null?`%${a.score}`:"—"}</td></tr>`).join("")||`<tr><td colspan="5">Atama yok.</td></tr>`}</tbody></table>
 <h2>Son sonuçlar</h2><table><thead><tr><th>Tarih</th><th>Tür</th><th>Ders / Konu</th><th>Başarı</th></tr></thead><tbody>${rs.slice(0,12).map(r=>`<tr><td>${r.date}</td><td>${r.kind}</td><td>${r.course} / ${r.topic}</td><td><span class="badge ${scoreClass(r.score)}">%${r.score}</span></td></tr>`).join("")||`<tr><td colspan="4">Sonuç yok.</td></tr>`}</tbody></table>`,"profile")
}
function curriculum(){
 let cards="";for(const [course,units] of Object.entries(db.curriculum)){cards+=`<div class="card"><div class="section-head"><h2 style="margin:0">${course}</h2><span class="badge info">${Object.values(units).reduce((n,x)=>n+x.length,0)} konu</span></div>`;for(const [u,topics] of Object.entries(units)){cards+=`<div class="item"><div class="cell-title">${u}</div><div style="margin-top:8px">${topics.map(t=>`<span class="badge neutral">${t}</span>`).join(" ")}</div></div>`}cards+="</div>"}
 shell(`${pageHead("Ders ve Üniteler","Ders, ünite ve alt konu yapısını yönetin.",`<button class="btn primary" onclick="currModal()">+ Müfredat Ekle</button>`)}<div class="list">${cards||emptyState("Müfredat boş","Ders ve konu ekleyerek başlayın.")}</div>`,"curriculum")
}
window.currModal=()=>modal(`<h2>Müfredat Ekle</h2><div class="formgrid"><div class="field"><label>Ders</label><input id="ccourse"></div><div class="field"><label>Ünite</label><input id="cunit"></div><div class="field"><label>Alt ünite / konu</label><input id="ctopic"></div></div><div class="modal-actions"><button class="btn primary" onclick="addCurr()">Kaydet</button></div>`)
window.addCurr=()=>{let c=q("ccourse").value.trim(),u=q("cunit").value.trim(),t=q("ctopic").value.trim();if(!c||!u||!t)return alert("Tüm alanlar gerekli");db.curriculum[c]??={};db.curriculum[c][u]??=[];if(!db.curriculum[c][u].includes(t))db.curriculum[c][u].push(t);save();closeModal();curriculum()}
function topicOptions(){let out="";for(const [c,units] of Object.entries(db.curriculum))for(const topics of Object.values(units))for(const t of topics)out+=`<option data-course="${c}" value="${c}|||${t}">${c} — ${t}</option>`;return out}
function resources(){
 const rows=db.resources.map(r=>`<tr><td><div class="cell-title">${r.title}</div><div class="cell-sub">${r.type||"PDF"}</div></td><td>${r.course}</td><td>${r.topic}</td><td><span class="badge neutral">${r.level}</span></td></tr>`).join("");
 shell(`${pageHead("Kaynak Havuzu","PDF ödev ve çalışma kaynaklarını ders, konu ve zorluk düzeyine göre yönetin.",`<button class="btn primary" onclick="resourceModal()">+ Kaynak Ekle</button>`)}${rows?tableWrap(`<table><thead><tr><th>Kaynak</th><th>Ders</th><th>Konu</th><th>Seviye</th></tr></thead><tbody>${rows}</tbody></table>`):emptyState("Kaynak bulunamadı","İlk PDF kaynağınızı ekleyin.")}`,"resources")
}
window.resourceModal=()=>modal(`<h2>Kaynak Ekle</h2><div class="formgrid"><div class="field"><label>Başlık</label><input id="rtitle"></div><div class="field"><label>Konu</label><select id="rtopic">${topicOptions()}</select></div><div class="field"><label>Zorluk</label><select id="rlevel"><option>Başlangıç</option><option>Kolay</option><option>Orta</option><option>Orta-Zor</option><option>Zor</option><option>İleri</option></select></div><div class="field"><label>Drive bağlantısı / File ID</label><input id="rurl"></div></div><div class="modal-actions"><button class="btn primary" onclick="addResource()">Kaydet</button></div>`)
window.addResource=()=>{const [course,topic]=q("rtopic").value.split("|||");db.resources.push({id:Date.now(),type:"PDF",course,topic,level:q("rlevel").value,title:q("rtitle").value||topic+" Kaynak",url:q("rurl").value});save();closeModal();resources()}
function exams(){
 const rows=db.exams.map(e=>`<tr><td><div class="cell-title">${e.title}</div></td><td>${e.course}</td><td>${e.topic}</td><td>${e.url?`<a href="${e.url}" target="_blank">Sınavı aç</a>`:"—"}</td></tr>`).join("");
 shell(`${pageHead("Online Sınavlar","Online test ve sınav bağlantılarını konu bazında yönetin.",`<button class="btn primary" onclick="examModal()">+ Sınav Ekle</button>`)}${rows?tableWrap(`<table><thead><tr><th>Sınav</th><th>Ders</th><th>Konu</th><th>Bağlantı</th></tr></thead><tbody>${rows}</tbody></table>`):emptyState("Online sınav yok","İlk sınav bağlantısını ekleyin.")}`,"exams")
}
window.examModal=()=>modal(`<h2>Online Sınav Ekle</h2><div class="formgrid"><div class="field"><label>Başlık</label><input id="etitle"></div><div class="field"><label>Konu</label><select id="etopic">${topicOptions()}</select></div><div class="field"><label>Link</label><input id="eurl"></div></div><div class="modal-actions"><button class="btn primary" onclick="addExam()">Kaydet</button></div>`)
window.addExam=()=>{const [course,topic]=q("etopic").value.split("|||");db.exams.push({id:Date.now(),course,topic,title:q("etitle").value||topic+" Online Test",url:q("eurl").value});save();closeModal();exams()}

function assignments(){
 const rows=db.assignments.slice().reverse().map(a=>`<tr><td><div class="cell-title">${studentName(a.studentId)}</div></td><td><span class="badge info">${a.kind}</span></td><td><div class="cell-title">${a.title}</div><div class="cell-sub">${a.course} · ${a.topic}</div></td><td><span class="badge ${a.status==="Tamamlandı"?"good":"mid"}">${a.status}</span></td><td>${a.status==="Tamamlandı"?`<span class="muted">Tamamlandı</span>`:`<button class="btn ghost small" onclick="completeAssignment(${a.id})">Sonuç gir</button>`}</td></tr>`).join("");
 shell(`${pageHead("Atamalar","Öğrencilere kaynak ve online sınav atayın, tamamlanma durumunu takip edin.",`<button class="btn primary" onclick="assignmentModal()">+ Yeni Atama</button>`)}${rows?tableWrap(`<table><thead><tr><th>Öğrenci</th><th>Tür</th><th>İçerik</th><th>Durum</th><th>İşlem</th></tr></thead><tbody>${rows}</tbody></table>`):emptyState("Henüz atama yok","Yeni atama oluşturarak çalışma akışını başlatın.")}`,"assignments")
}
window.assignmentModal=()=>modal(`<h2>Yeni Atama</h2><div class="formgrid">
<div class="field"><label>Öğrenci</label><select id="astudent">${db.students.map(s=>`<option value="${s.id}">${s.name}</option>`).join("")}</select></div>
<div class="field"><label>Atama türü</label><select id="akind" onchange="refreshAssignmentItems()"><option>PDF Kaynak</option><option>Online Sınav</option></select></div>
<div class="field" style="grid-column:1/-1"><label>İçerik</label><select id="aitem"></select></div>
</div><div class="modal-actions"><button class="btn primary" onclick="addAssignment()">Ata</button> <button class="btn ghost" onclick="closeModal()">İptal</button></div>`)
window.refreshAssignmentItems=()=>{const k=q("akind").value,items=k==="PDF Kaynak"?db.resources:db.exams;q("aitem").innerHTML=items.map(x=>`<option value="${x.id}">${x.title} — ${x.course} / ${x.topic}</option>`).join("")}
window.addAssignment=()=>{const kind=q("akind").value,items=kind==="PDF Kaynak"?db.resources:db.exams,item=items.find(x=>x.id===Number(q("aitem").value));if(!item)return alert("Atanabilir içerik yok");db.assignments.push({id:Date.now(),studentId:Number(q("astudent").value),kind,title:item.title,course:item.course,topic:item.topic,sourceId:item.id,status:"Bekliyor",assignedAt:new Date().toISOString().slice(0,10)});save();closeModal();assignments()}
window.completeAssignment=id=>{const a=db.assignments.find(x=>x.id===id);if(!a)return;modal(`<h2>Atamayı Tamamla</h2><p><b>${a.title}</b><br>${studentName(a.studentId)} — ${a.course} / ${a.topic}</p><div class="field"><label>Başarı %</label><input id="ascore" type="number" min="0" max="100"></div><div class="modal-actions"><button class="btn primary" onclick="saveAssignmentResult(${id})">Kaydet</button></div>`)}
window.saveAssignmentResult=id=>{const a=db.assignments.find(x=>x.id===id);if(!a)return;const score=Math.max(0,Math.min(100,Number(q("ascore").value)));a.status="Tamamlandı";a.completedAt=new Date().toISOString().slice(0,10);a.score=score;db.results.push({id:Date.now(),studentId:a.studentId,kind:a.kind==="PDF Kaynak"?"Ödev":"Online Sınav",course:a.course,topic:a.topic,score,date:a.completedAt,assignmentId:a.id});save();closeModal();assignments()}
function results(){
 const rows=db.results.slice().reverse().map(r=>`<tr><td><div class="cell-title">${studentName(r.studentId)}</div></td><td>${r.kind}</td><td><div class="cell-title">${r.topic}</div><div class="cell-sub">${r.course}</div></td><td><span class="badge ${scoreClass(r.score)}">%${r.score}</span></td><td>${r.date}</td></tr>`).join("");
 shell(`${pageHead("Başarı Sonuçları","Ödev ve online sınav başarılarını kaydedin. Adaptif tekrar eşiği %${db.threshold}.",`<button class="btn primary" onclick="resultModal()">+ Sonuç Gir</button>`)}${rows?tableWrap(`<table><thead><tr><th>Öğrenci</th><th>Tür</th><th>Konu</th><th>Başarı</th><th>Tarih</th></tr></thead><tbody>${rows}</tbody></table>`):emptyState("Sonuç bulunamadı","İlk ödev veya sınav sonucunu girin.")}`,"results")
}
window.resultModal=()=>modal(`<h2>Sonuç Gir</h2><div class="formgrid"><div class="field"><label>Öğrenci</label><select id="xstudent">${db.students.map(s=>`<option value="${s.id}">${s.name}</option>`).join("")}</select></div><div class="field"><label>Tür</label><select id="xkind"><option>Ödev</option><option>Online Sınav</option></select></div><div class="field"><label>Konu</label><select id="xtopic">${topicOptions()}</select></div><div class="field"><label>Başarı %</label><input id="xscore" type="number" min="0" max="100"></div></div><div class="modal-actions"><button class="btn primary" onclick="addResult()">Kaydet</button></div>`)
window.addResult=()=>{const [course,topic]=q("xtopic").value.split("|||"),score=Math.max(0,Math.min(100,Number(q("xscore").value)));db.results.push({id:Date.now(),studentId:Number(q("xstudent").value),kind:q("xkind").value,course,topic,score,date:new Date().toISOString().slice(0,10)});save();closeModal();results()}


let selectedStudentId=null;
const DAY_NAMES=["Pazartesi","Salı","Çarşamba","Perşembe","Cuma","Cumartesi","Pazar"];
function buildPlanItems(s){
 const latest={};
 db.results.filter(r=>r.studentId===s.id).forEach(r=>{const k=r.course+"|||"+r.topic;if(!latest[k]||String(r.date)>=String(latest[k].date))latest[k]=r});
 const repeats=Object.values(latest).filter(r=>r.score<db.threshold).map(r=>{
   const wanted=s.levels?.[r.course]||"Orta";
   const res=db.resources.find(x=>x.course===r.course&&x.topic===r.topic&&x.level===wanted)||db.resources.find(x=>x.course===r.course&&x.topic===r.topic);
   const exam=db.exams.find(x=>x.course===r.course&&x.topic===r.topic);
   return {type:"Tekrar",course:r.course,topic:r.topic,level:wanted,resource:res?.title||"Uygun kaynak ekleyin",exam:exam?.title||"—",reason:`Son başarı %${r.score}`,priority:0}
 });
 const pending=db.assignments.filter(a=>a.studentId===s.id&&a.status!=="Tamamlandı").map(a=>({
   type:"Atama",course:a.course,topic:a.topic,level:s.levels?.[a.course]||"Orta",
   resource:a.kind==="PDF Kaynak"?a.title:"—",exam:a.kind==="Online Sınav"?a.title:"—",
   reason:"Bekleyen atama",priority:1
 }));
 const map=new Map();
 [...repeats,...pending].forEach(x=>{const k=x.type+"|||"+x.course+"|||"+x.topic+"|||"+x.resource+"|||"+x.exam;if(!map.has(k))map.set(k,x)});
 return [...map.values()].sort((a,b)=>a.priority-b.priority||a.course.localeCompare(b.course));
}
function generateWeeklyPlan(){
 const s=db.students.find(x=>x.id===selectedStudentId);if(!s)return;
 const items=buildPlanItems(s);
 const days=Object.fromEntries(DAY_NAMES.map(d=>[d,[]]));
 items.forEach((item,i)=>days[DAY_NAMES[i%7]].push(item));
 db.weeklyPlans[String(s.id)]={generatedAt:new Date().toISOString(),days};
 save();program()
}
function program(){
 if(!db.students.length){shell(`${pageHead("Haftalık Program","Öğrenciye özel adaptif çalışma planı.")}${emptyState("Öğrenci bulunamadı","Program oluşturmak için önce öğrenci ekleyin.")}`,"program");return}
 if(!selectedStudentId||!db.students.some(s=>s.id===selectedStudentId))selectedStudentId=db.students[0].id;
 const s=db.students.find(x=>x.id===selectedStudentId),key=String(s.id),saved=db.weeklyPlans?.[key];
 const preview=saved?.days||(()=>{const days=Object.fromEntries(DAY_NAMES.map(d=>[d,[]]));buildPlanItems(s).forEach((x,i)=>days[DAY_NAMES[i%7]].push(x));return days})();
 const total=Object.values(preview).reduce((n,a)=>n+a.length,0);
 const actions=`<div class="toolbar-group"><select onchange="selectedStudentId=Number(this.value);program()">${db.students.map(x=>`<option value="${x.id}" ${x.id===s.id?"selected":""}>${x.name}</option>`).join("")}</select><button class="btn primary" onclick="generateWeeklyPlan()">Programı Oluştur / Yenile</button></div>`;
 shell(`${pageHead("Haftalık Program","Adaptif planlayıcı tekrar ihtiyaçlarını ve bekleyen atamaları 7 güne dengeli dağıtır.",actions)}
 <div class="notice"><div><b>Planlama kuralı</b>Önce %${db.threshold} altındaki konular, ardından bekleyen atamalar. Toplam görev: ${total}. ${saved?`Son kayıt: ${new Date(saved.generatedAt).toLocaleString("tr-TR")}`:"Henüz kaydedilmedi; aşağıdaki görünüm önizlemedir."}</div></div>
 <div class="section"><div class="weekgrid">${DAY_NAMES.map(d=>`<div class="daycard"><h3>${d}</h3>${preview[d].map(x=>`<div class="task"><div class="task-title">${x.type} · ${x.course}</div><div class="task-sub">${x.topic}<br>${x.resource!=="—"?x.resource:x.exam}</div><span class="badge ${x.type==="Tekrar"?"low":"mid"}">${x.reason}</span></div>`).join("")||`<div class="muted">Görev yok</div>`}</div>`).join("")}</div></div>`,"program")
}
function q(id){return document.getElementById(id)}
function modal(html){const d=document.createElement("div");d.className="modalbg";d.id="modalbg";d.innerHTML=`<div class="modal">${html}</div>`;document.body.appendChild(d)}
window.closeModal=()=>document.getElementById("modalbg")?.remove()
window.resetDemo=()=>{db=structuredClone(seed);save();render()}
dashboard();
