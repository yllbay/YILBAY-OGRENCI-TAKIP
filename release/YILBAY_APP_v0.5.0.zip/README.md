# YILBAY Öğrenci Takip — v0.5.0

Kurumsal UI/UX refaktörü:
- Standart tasarım sistemi ve kurumsal renk paleti
- Daha sade bilgi mimarisi ve grup bazlı sol navigasyon
- Yeni dashboard KPI kartları ve öncelikli tekrar görünümü
- Profesyonel tablo, form, modal, buton ve badge sistemi
- Daha güçlü tipografi, boşluk, kontrast ve responsive davranış
- Öğrenci listesinde daha okunabilir ders/seviye görünümü
- Haftalık program için kurumsal planlama görünümü
- v0.4.5 verisini otomatik v0.5.0 depolamasına taşır
