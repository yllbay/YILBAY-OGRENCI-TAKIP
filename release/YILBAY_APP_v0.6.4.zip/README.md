# YILBAY Öğrenci Takip — v0.6.4

Credential Manager tüm credential türleriyle enumerate edilir; hedef son ek eşleşmesi desteklenir. cmdkey yalnızca güvenli varlık teşhisi için kullanılır. API anahtarı log/rapora yazılmaz.
