const STORAGE="yilbay_mvp_040";
const seed={
 students:[{id:1,name:"Bilgehan Özdurak",grade:"12",target:"YKS",courses:["TYT Matematik","Problemler","Türkçe"],levels:{"TYT Matematik":"Orta","Problemler":"Orta-Zor","Türkçe":"Orta"}}],
 curriculum:{
   "TYT Matematik":{"Temel Matematik":["Temel Kavramlar","Bölme-Bölünebilme","Rasyonel Sayılar","1. Derece Denklemler","Basit Eşitsizlikler","Mutlak Değer"]},
   "Problemler":{"Problemler":["Sayı Problemleri","Kesir Problemleri","Yaş Problemleri"]},
   "Türkçe":{"Paragraf":["Paragrafta Konu","Paragrafta Başlık","Ana Düşünce"],"Dil Bilgisi":["Yazım Kuralları","Ses Bilgisi"]}
 },
 resources:[
  {id:1,type:"PDF",course:"TYT Matematik",topic:"Mutlak Değer",level:"Orta",title:"Mutlak Değer Ödev 01",url:""},
  {id:2,type:"PDF",course:"Problemler",topic:"Sayı Problemleri",level:"Orta-Zor",title:"Sayı Problemleri Ödev 01",url:""}
 ],
 exams:[
  {id:1,course:"TYT Matematik",topic:"Mutlak Değer",title:"Mutlak Değer Online Test",url:"https://example.com"}
 ],
 results:[
  {id:1,studentId:1,kind:"Ödev",course:"TYT Matematik",topic:"Mutlak Değer",score:58,date:"2026-08-25"},
  {id:2,studentId:1,kind:"Online Sınav",course:"TYT Matematik",topic:"Basit Eşitsizlikler",score:74,date:"2026-08-25"}
 ],
 threshold:70
};
let db=load(), view="dashboard";
function load(){try{return JSON.parse(localStorage.getItem(STORAGE))||structuredClone(seed)}catch{return structuredClone(seed)}}
function save(){localStorage.setItem(STORAGE,JSON.stringify(db))}
const app=()=>document.getElementById("app");
const scoreClass=n=>n>=80?"good":n>=60?"mid":"low";
function shell(content,active=view){app().innerHTML=`<div class="top"><div class="brand">YILBAY | Öğrenci Takip</div><div class="muted">MVP v0.4.0</div></div><div class="layout"><aside>
${nav("dashboard","Genel Bakış",active)}${nav("students","Öğrenciler",active)}${nav("curriculum","Ders / Ünite",active)}${nav("resources","Kaynaklar",active)}${nav("exams","Online Sınavlar",active)}${nav("results","Başarı Girişi",active)}${nav("program","Haftalık Program",active)}
</aside><main>${content}</main></div>`}
function nav(k,t,a){return `<button class="nav ${a===k?"active":""}" onclick="go('${k}')">${t}</button>`}
window.go=k=>{view=k;render()}
function render(){({dashboard,students,curriculum,resources,exams,results,program}[view]||dashboard)()}
function dashboard(){
 const low=db.results.filter(r=>r.score<db.threshold);
 shell(`<h1>Genel Bakış</h1><div class="grid">
 <div class="card"><div class="muted">Öğrenci</div><div class="kpi">${db.students.length}</div></div>
 <div class="card"><div class="muted">Kaynak</div><div class="kpi">${db.resources.length}</div></div>
 <div class="card"><div class="muted">Online sınav</div><div class="kpi">${db.exams.length}</div></div>
 <div class="card"><div class="muted">Tekrar gereken sonuç</div><div class="kpi">${low.length}</div></div></div>
 <h2>Tekrar gerektiren konular</h2><div class="list">${low.map(r=>`<div class="item"><b>${studentName(r.studentId)}</b> — ${r.course} / ${r.topic} <span class="badge low">%${r.score}</span></div>`).join("")||"<div class='card'>Yok</div>"}</div>`,"dashboard")
}
function studentName(id){return db.students.find(s=>s.id===id)?.name||"Bilinmeyen"}
function students(){
 shell(`<div class="toolbar"><h1>Öğrenciler</h1><button class="btn primary" onclick="studentModal()">+ Yeni Öğrenci</button></div>
 <table><thead><tr><th>Ad Soyad</th><th>Sınıf</th><th>Hedef</th><th>Koçluk dersleri</th></tr></thead><tbody>${db.students.map(s=>`<tr><td><b>${s.name}</b></td><td>${s.grade}</td><td>${s.target}</td><td>${s.courses.join(", ")}</td></tr>`).join("")}</tbody></table>`,"students")
}
window.studentModal=()=>modal(`<h2>Yeni Öğrenci</h2><div class="formgrid">
<div class="field"><label>Ad Soyad</label><input id="sname"></div><div class="field"><label>Sınıf</label><input id="sgrade"></div>
<div class="field"><label>Hedef</label><input id="starget" value="YKS"></div></div>
<h3>Koçluk dersleri</h3>${Object.keys(db.curriculum).map(c=>`<label><input type="checkbox" class="coursecheck" value="${c}"> ${c}</label><br>`).join("")}
<div style="margin-top:16px"><button class="btn primary" onclick="addStudent()">Kaydet</button> <button class="btn ghost" onclick="closeModal()">İptal</button></div>`)
window.addStudent=()=>{const name=q("sname").value.trim();if(!name)return alert("Ad soyad gerekli");const courses=[...document.querySelectorAll(".coursecheck:checked")].map(x=>x.value);db.students.push({id:Date.now(),name,grade:q("sgrade").value,target:q("starget").value,courses,levels:{}});save();closeModal();students()}
function curriculum(){
 let html="";for(const [course,units] of Object.entries(db.curriculum)){html+=`<div class="card"><h3>${course}</h3>`;for(const [u,topics] of Object.entries(units)){html+=`<b>${u}</b><p>${topics.map(t=>`<span class="badge mid">${t}</span>`).join(" ")}</p>`}html+="</div><br>"}
 shell(`<div class="toolbar"><h1>Ders / Ünite / Alt Ünite</h1><button class="btn primary" onclick="currModal()">+ Ekle</button></div>${html}`,"curriculum")
}
window.currModal=()=>modal(`<h2>Müfredat Ekle</h2><div class="formgrid"><div class="field"><label>Ders</label><input id="ccourse"></div><div class="field"><label>Ünite</label><input id="cunit"></div><div class="field"><label>Alt ünite / konu</label><input id="ctopic"></div></div><div style="margin-top:16px"><button class="btn primary" onclick="addCurr()">Kaydet</button></div>`)
window.addCurr=()=>{let c=q("ccourse").value.trim(),u=q("cunit").value.trim(),t=q("ctopic").value.trim();if(!c||!u||!t)return alert("Tüm alanlar gerekli");db.curriculum[c]??={};db.curriculum[c][u]??=[];if(!db.curriculum[c][u].includes(t))db.curriculum[c][u].push(t);save();closeModal();curriculum()}
function topicOptions(){let out="";for(const [c,units] of Object.entries(db.curriculum))for(const topics of Object.values(units))for(const t of topics)out+=`<option data-course="${c}" value="${c}|||${t}">${c} — ${t}</option>`;return out}
function resources(){
 shell(`<div class="toolbar"><h1>PDF / Kaynak Havuzu</h1><button class="btn primary" onclick="resourceModal()">+ Kaynak Ekle</button></div>
 <table><thead><tr><th>Kaynak</th><th>Ders</th><th>Konu</th><th>Seviye</th></tr></thead><tbody>${db.resources.map(r=>`<tr><td>${r.title}</td><td>${r.course}</td><td>${r.topic}</td><td>${r.level}</td></tr>`).join("")}</tbody></table>`,"resources")
}
window.resourceModal=()=>modal(`<h2>Kaynak Ekle</h2><div class="formgrid"><div class="field"><label>Başlık</label><input id="rtitle"></div><div class="field"><label>Konu</label><select id="rtopic">${topicOptions()}</select></div><div class="field"><label>Zorluk</label><select id="rlevel"><option>Başlangıç</option><option>Kolay</option><option>Orta</option><option>Orta-Zor</option><option>Zor</option><option>İleri</option></select></div><div class="field"><label>Drive bağlantısı / File ID</label><input id="rurl"></div></div><div style="margin-top:16px"><button class="btn primary" onclick="addResource()">Kaydet</button></div>`)
window.addResource=()=>{const [course,topic]=q("rtopic").value.split("|||");db.resources.push({id:Date.now(),type:"PDF",course,topic,level:q("rlevel").value,title:q("rtitle").value||topic+" Kaynak",url:q("rurl").value});save();closeModal();resources()}
function exams(){
 shell(`<div class="toolbar"><h1>Online Sınav Havuzu</h1><button class="btn primary" onclick="examModal()">+ Sınav Ekle</button></div>
 <table><thead><tr><th>Sınav</th><th>Ders</th><th>Konu</th><th>Link</th></tr></thead><tbody>${db.exams.map(e=>`<tr><td>${e.title}</td><td>${e.course}</td><td>${e.topic}</td><td>${e.url?`<a href="${e.url}" target="_blank">Aç</a>`:"—"}</td></tr>`).join("")}</tbody></table>`,"exams")
}
window.examModal=()=>modal(`<h2>Online Sınav Ekle</h2><div class="formgrid"><div class="field"><label>Başlık</label><input id="etitle"></div><div class="field"><label>Konu</label><select id="etopic">${topicOptions()}</select></div><div class="field"><label>Link</label><input id="eurl"></div></div><div style="margin-top:16px"><button class="btn primary" onclick="addExam()">Kaydet</button></div>`)
window.addExam=()=>{const [course,topic]=q("etopic").value.split("|||");db.exams.push({id:Date.now(),course,topic,title:q("etitle").value||topic+" Online Test",url:q("eurl").value});save();closeModal();exams()}
function results(){
 shell(`<div class="toolbar"><h1>Başarı Girişi</h1><button class="btn primary" onclick="resultModal()">+ Sonuç Gir</button></div>
 <p class="muted">Tekrar eşiği: %${db.threshold}</p><table><thead><tr><th>Öğrenci</th><th>Tür</th><th>Konu</th><th>Başarı</th><th>Tarih</th></tr></thead><tbody>
 ${db.results.slice().reverse().map(r=>`<tr><td>${studentName(r.studentId)}</td><td>${r.kind}</td><td>${r.course} / ${r.topic}</td><td><span class="badge ${scoreClass(r.score)}">%${r.score}</span></td><td>${r.date}</td></tr>`).join("")}</tbody></table>`,"results")
}
window.resultModal=()=>modal(`<h2>Sonuç Gir</h2><div class="formgrid"><div class="field"><label>Öğrenci</label><select id="xstudent">${db.students.map(s=>`<option value="${s.id}">${s.name}</option>`).join("")}</select></div><div class="field"><label>Tür</label><select id="xkind"><option>Ödev</option><option>Online Sınav</option></select></div><div class="field"><label>Konu</label><select id="xtopic">${topicOptions()}</select></div><div class="field"><label>Başarı %</label><input id="xscore" type="number" min="0" max="100"></div></div><div style="margin-top:16px"><button class="btn primary" onclick="addResult()">Kaydet</button></div>`)
window.addResult=()=>{const [course,topic]=q("xtopic").value.split("|||"),score=Math.max(0,Math.min(100,Number(q("xscore").value)));db.results.push({id:Date.now(),studentId:Number(q("xstudent").value),kind:q("xkind").value,course,topic,score,date:new Date().toISOString().slice(0,10)});save();closeModal();results()}
function program(){
 const s=db.students[0];const repeats=db.results.filter(r=>r.studentId===s.id&&r.score<db.threshold);
 const unique=[...new Map(repeats.map(r=>[r.course+"|||"+r.topic,r])).values()];
 const rows=unique.map(r=>{const res=db.resources.find(x=>x.course===r.course&&x.topic===r.topic);const exam=db.exams.find(x=>x.course===r.course&&x.topic===r.topic);return `<tr><td><b>Tekrar</b></td><td>${r.course}</td><td>${r.topic}</td><td>${res?.title||"Uygun kaynak ekleyin"}</td><td>${exam?.title||"—"}</td><td><span class="badge low">Önceki %${r.score}</span></td></tr>`}).join("");
 shell(`<h1>Haftalık Program — ${s.name}</h1><p class="muted">Adaptif motor: başarı %${db.threshold} altındaysa konu sonraki haftaya tekrar olarak taşınır.</p>
 <table><thead><tr><th>Tür</th><th>Ders</th><th>Konu</th><th>PDF / Kaynak</th><th>Online Sınav</th><th>Neden</th></tr></thead><tbody>${rows||`<tr><td colspan="6">Tekrar gerektiren konu yok.</td></tr>`}</tbody></table>`,"program")
}
function q(id){return document.getElementById(id)}
function modal(html){const d=document.createElement("div");d.className="modalbg";d.id="modalbg";d.innerHTML=`<div class="modal">${html}</div>`;document.body.appendChild(d)}
window.closeModal=()=>document.getElementById("modalbg")?.remove()
window.resetDemo=()=>{db=structuredClone(seed);save();render()}
dashboard();
