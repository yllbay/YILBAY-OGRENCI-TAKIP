const STORAGE="yilbay_mvp_044";
const PREV_STORAGE="yilbay_mvp_043";
const OLD_STORAGE="yilbay_mvp_040";
const seed={
 students:[{id:1,name:"Bilgehan Özdurak",grade:"12",target:"YKS",courses:["TYT Matematik","Problemler","Türkçe"],levels:{"TYT Matematik":"Orta","Problemler":"Orta-Zor","Türkçe":"Orta"}}],
 curriculum:{
   "TYT Matematik":{"Temel Matematik":["Temel Kavramlar","Bölme-Bölünebilme","Rasyonel Sayılar","1. Derece Denklemler","Basit Eşitsizlikler","Mutlak Değer"]},
   "Problemler":{"Problemler":["Sayı Problemleri","Kesir Problemleri","Yaş Problemleri"]},
   "Türkçe":{"Paragraf":["Paragrafta Konu","Paragrafta Başlık","Ana Düşünce"],"Dil Bilgisi":["Yazım Kuralları","Ses Bilgisi"]}
 },
 resources:[
  {id:1,type:"PDF",course:"TYT Matematik",topic:"Mutlak Değer",level:"Orta",title:"Mutlak Değer Ödev 01",url:""},
  {id:2,type:"PDF",course:"Problemler",topic:"Sayı Problemleri",level:"Orta-Zor",title:"Sayı Problemleri Ödev 01",url:""}
 ],
 exams:[
  {id:1,course:"TYT Matematik",topic:"Mutlak Değer",title:"Mutlak Değer Online Test",url:"https://example.com"}
 ],
 results:[
  {id:1,studentId:1,kind:"Ödev",course:"TYT Matematik",topic:"Mutlak Değer",score:58,date:"2026-08-25"},
  {id:2,studentId:1,kind:"Online Sınav",course:"TYT Matematik",topic:"Basit Eşitsizlikler",score:74,date:"2026-08-25"}
 ],
 threshold:70
};
let db=load(), view="dashboard";
function load(){try{
 const current=localStorage.getItem(STORAGE);
 if(current) return normalizeDb(JSON.parse(current));
 const prev=localStorage.getItem(PREV_STORAGE);
 if(prev){const migrated=normalizeDb(JSON.parse(prev)); localStorage.setItem(STORAGE,JSON.stringify(migrated)); return migrated;}
 const old=localStorage.getItem(OLD_STORAGE);
 if(old){const migrated=normalizeDb(JSON.parse(old)); localStorage.setItem(STORAGE,JSON.stringify(migrated)); return migrated;}
 return normalizeDb(structuredClone(seed))
}catch{return normalizeDb(structuredClone(seed))}}
function normalizeDb(x){
 x.assignments??=[];
 x.threshold??=70;
 return x
}
function save(){localStorage.setItem(STORAGE,JSON.stringify(db))}
const app=()=>document.getElementById("app");
const scoreClass=n=>n>=80?"good":n>=60?"mid":"low";
function shell(content,active=view){app().innerHTML=`<div class="top"><div class="brand">YILBAY | Öğrenci Takip</div><div class="muted">MVP v0.4.4</div></div><div class="layout"><aside>
${nav("dashboard","Genel Bakış",active)}${nav("students","Öğrenciler",active)}${nav("curriculum","Ders / Ünite",active)}${nav("resources","Kaynaklar",active)}${nav("exams","Online Sınavlar",active)}${nav("assignments","Atamalar",active)}${nav("results","Başarı Girişi",active)}${nav("program","Haftalık Program",active)}
</aside><main>${content}</main></div>`}
function nav(k,t,a){return `<button class="nav ${a===k?"active":""}" onclick="go('${k}')">${t}</button>`}
window.go=k=>{view=k;render()}
function render(){({dashboard,students,curriculum,resources,exams,assignments,results,program}[view]||dashboard)()}
function dashboard(){
 const low=db.results.filter(r=>r.score<db.threshold);
 shell(`<h1>Genel Bakış</h1><div class="grid">
 <div class="card"><div class="muted">Öğrenci</div><div class="kpi">${db.students.length}</div></div>
 <div class="card"><div class="muted">Kaynak</div><div class="kpi">${db.resources.length}</div></div>
 <div class="card"><div class="muted">Online sınav</div><div class="kpi">${db.exams.length}</div></div>
 <div class="card"><div class="muted">Bekleyen atama</div><div class="kpi">${db.assignments.filter(a=>a.status!=="Tamamlandı").length}</div></div>
 <div class="card"><div class="muted">Tekrar gereken sonuç</div><div class="kpi">${low.length}</div></div></div>
 <h2>Tekrar gerektiren konular</h2><div class="list">${low.map(r=>`<div class="item"><b>${studentName(r.studentId)}</b> — ${r.course} / ${r.topic} <span class="badge low">%${r.score}</span></div>`).join("")||"<div class='card'>Yok</div>"}</div>`,"dashboard")
}
function studentName(id){return db.students.find(s=>s.id===id)?.name||"Bilinmeyen"}

function students(){
 shell(`<div class="toolbar"><h1>Öğrenciler</h1><button class="btn primary" onclick="studentModal()">+ Yeni Öğrenci</button></div>
 <table><thead><tr><th>Ad Soyad</th><th>Sınıf</th><th>Hedef</th><th>Koçluk dersleri / seviyeler</th><th>İşlem</th></tr></thead><tbody>${db.students.map(s=>`<tr><td><b>${s.name}</b></td><td>${s.grade}</td><td>${s.target}</td><td>${s.courses.map(c=>`${c} <span class="badge mid">${s.levels?.[c]||"Seviye yok"}</span>`).join("<br>")}</td><td><button class="btn ghost" onclick="editStudent(${s.id})">Düzenle</button> <button class="btn ghost danger" onclick="deleteStudent(${s.id})">Sil</button></td></tr>`).join("")}</tbody></table>`,"students")
}
function courseLevelFields(selected=[],levels={}){
 return Object.keys(db.curriculum).map(c=>`<div class="item"><label><input type="checkbox" class="coursecheck" value="${c}" ${selected.includes(c)?"checked":""}> <b>${c}</b></label>
 <select class="courselevel" data-course="${c}"><option>Başlangıç</option><option>Kolay</option><option ${levels[c]==="Orta"?"selected":""}>Orta</option><option ${levels[c]==="Orta-Zor"?"selected":""}>Orta-Zor</option><option ${levels[c]==="Zor"?"selected":""}>Zor</option><option ${levels[c]==="İleri"?"selected":""}>İleri</option></select></div>`).join("")
}
window.studentModal=()=>modal(`<h2>Yeni Öğrenci</h2><div class="formgrid">
<div class="field"><label>Ad Soyad</label><input id="sname"></div><div class="field"><label>Sınıf</label><input id="sgrade"></div>
<div class="field"><label>Hedef</label><input id="starget" value="YKS"></div></div>
<h3>Koçluk dersleri ve kaynak seviyesi</h3><div class="list">${courseLevelFields()}</div>
<div style="margin-top:16px"><button class="btn primary" onclick="addStudent()">Kaydet</button> <button class="btn ghost" onclick="closeModal()">İptal</button></div>`)
function readStudentCourses(){
 const courses=[...document.querySelectorAll(".coursecheck:checked")].map(x=>x.value),levels={};
 courses.forEach(c=>{levels[c]=document.querySelector(`.courselevel[data-course="${c}"]`)?.value||"Orta"});
 return {courses,levels}
}
window.addStudent=()=>{const name=q("sname").value.trim();if(!name)return alert("Ad soyad gerekli");const x=readStudentCourses();db.students.push({id:Date.now(),name,grade:q("sgrade").value,target:q("starget").value,courses:x.courses,levels:x.levels});save();closeModal();students()}
window.editStudent=id=>{const s=db.students.find(x=>x.id===id);if(!s)return;modal(`<h2>Öğrenci Düzenle</h2><input type="hidden" id="sid" value="${id}"><div class="formgrid"><div class="field"><label>Ad Soyad</label><input id="sname" value="${s.name}"></div><div class="field"><label>Sınıf</label><input id="sgrade" value="${s.grade||""}"></div><div class="field"><label>Hedef</label><input id="starget" value="${s.target||""}"></div></div><h3>Dersler / seviyeler</h3><div class="list">${courseLevelFields(s.courses||[],s.levels||{})}</div><div style="margin-top:16px"><button class="btn primary" onclick="saveStudentEdit()">Kaydet</button> <button class="btn ghost" onclick="closeModal()">İptal</button></div>`)}
window.saveStudentEdit=()=>{const id=Number(q("sid").value),s=db.students.find(x=>x.id===id);if(!s)return;const x=readStudentCourses();s.name=q("sname").value.trim();s.grade=q("sgrade").value;s.target=q("starget").value;s.courses=x.courses;s.levels=x.levels;save();closeModal();students()}
window.deleteStudent=id=>{if(!confirm("Öğrenci silinsin mi?"))return;db.students=db.students.filter(s=>s.id!==id);db.results=db.results.filter(r=>r.studentId!==id);save();students()}
function curriculum(){
 let html="";for(const [course,units] of Object.entries(db.curriculum)){html+=`<div class="card"><h3>${course}</h3>`;for(const [u,topics] of Object.entries(units)){html+=`<b>${u}</b><p>${topics.map(t=>`<span class="badge mid">${t}</span>`).join(" ")}</p>`}html+="</div><br>"}
 shell(`<div class="toolbar"><h1>Ders / Ünite / Alt Ünite</h1><button class="btn primary" onclick="currModal()">+ Ekle</button></div>${html}`,"curriculum")
}
window.currModal=()=>modal(`<h2>Müfredat Ekle</h2><div class="formgrid"><div class="field"><label>Ders</label><input id="ccourse"></div><div class="field"><label>Ünite</label><input id="cunit"></div><div class="field"><label>Alt ünite / konu</label><input id="ctopic"></div></div><div style="margin-top:16px"><button class="btn primary" onclick="addCurr()">Kaydet</button></div>`)
window.addCurr=()=>{let c=q("ccourse").value.trim(),u=q("cunit").value.trim(),t=q("ctopic").value.trim();if(!c||!u||!t)return alert("Tüm alanlar gerekli");db.curriculum[c]??={};db.curriculum[c][u]??=[];if(!db.curriculum[c][u].includes(t))db.curriculum[c][u].push(t);save();closeModal();curriculum()}
function topicOptions(){let out="";for(const [c,units] of Object.entries(db.curriculum))for(const topics of Object.values(units))for(const t of topics)out+=`<option data-course="${c}" value="${c}|||${t}">${c} — ${t}</option>`;return out}
function resources(){
 shell(`<div class="toolbar"><h1>PDF / Kaynak Havuzu</h1><button class="btn primary" onclick="resourceModal()">+ Kaynak Ekle</button></div>
 <table><thead><tr><th>Kaynak</th><th>Ders</th><th>Konu</th><th>Seviye</th></tr></thead><tbody>${db.resources.map(r=>`<tr><td>${r.title}</td><td>${r.course}</td><td>${r.topic}</td><td>${r.level}</td></tr>`).join("")}</tbody></table>`,"resources")
}
window.resourceModal=()=>modal(`<h2>Kaynak Ekle</h2><div class="formgrid"><div class="field"><label>Başlık</label><input id="rtitle"></div><div class="field"><label>Konu</label><select id="rtopic">${topicOptions()}</select></div><div class="field"><label>Zorluk</label><select id="rlevel"><option>Başlangıç</option><option>Kolay</option><option>Orta</option><option>Orta-Zor</option><option>Zor</option><option>İleri</option></select></div><div class="field"><label>Drive bağlantısı / File ID</label><input id="rurl"></div></div><div style="margin-top:16px"><button class="btn primary" onclick="addResource()">Kaydet</button></div>`)
window.addResource=()=>{const [course,topic]=q("rtopic").value.split("|||");db.resources.push({id:Date.now(),type:"PDF",course,topic,level:q("rlevel").value,title:q("rtitle").value||topic+" Kaynak",url:q("rurl").value});save();closeModal();resources()}
function exams(){
 shell(`<div class="toolbar"><h1>Online Sınav Havuzu</h1><button class="btn primary" onclick="examModal()">+ Sınav Ekle</button></div>
 <table><thead><tr><th>Sınav</th><th>Ders</th><th>Konu</th><th>Link</th></tr></thead><tbody>${db.exams.map(e=>`<tr><td>${e.title}</td><td>${e.course}</td><td>${e.topic}</td><td>${e.url?`<a href="${e.url}" target="_blank">Aç</a>`:"—"}</td></tr>`).join("")}</tbody></table>`,"exams")
}
window.examModal=()=>modal(`<h2>Online Sınav Ekle</h2><div class="formgrid"><div class="field"><label>Başlık</label><input id="etitle"></div><div class="field"><label>Konu</label><select id="etopic">${topicOptions()}</select></div><div class="field"><label>Link</label><input id="eurl"></div></div><div style="margin-top:16px"><button class="btn primary" onclick="addExam()">Kaydet</button></div>`)
window.addExam=()=>{const [course,topic]=q("etopic").value.split("|||");db.exams.push({id:Date.now(),course,topic,title:q("etitle").value||topic+" Online Test",url:q("eurl").value});save();closeModal();exams()}

function assignments(){
 shell(`<div class="toolbar"><h1>Atamalar</h1><button class="btn primary" onclick="assignmentModal()">+ Yeni Atama</button></div>
 <table><thead><tr><th>Öğrenci</th><th>Tür</th><th>İçerik</th><th>Ders / Konu</th><th>Durum</th><th>İşlem</th></tr></thead><tbody>
 ${db.assignments.slice().reverse().map(a=>`<tr><td>${studentName(a.studentId)}</td><td>${a.kind}</td><td>${a.title}</td><td>${a.course} / ${a.topic}</td><td><span class="badge ${a.status==="Tamamlandı"?"good":"mid"}">${a.status}</span></td><td>${a.status==="Tamamlandı"?"—":`<button class="btn ghost" onclick="completeAssignment(${a.id})">Tamamlandı</button>`}</td></tr>`).join("")||`<tr><td colspan="6">Henüz atama yok.</td></tr>`}
 </tbody></table>`,"assignments")
}
window.assignmentModal=()=>modal(`<h2>Yeni Atama</h2><div class="formgrid">
<div class="field"><label>Öğrenci</label><select id="astudent">${db.students.map(s=>`<option value="${s.id}">${s.name}</option>`).join("")}</select></div>
<div class="field"><label>Atama türü</label><select id="akind" onchange="refreshAssignmentItems()"><option>PDF Kaynak</option><option>Online Sınav</option></select></div>
<div class="field" style="grid-column:1/-1"><label>İçerik</label><select id="aitem"></select></div>
</div><div style="margin-top:16px"><button class="btn primary" onclick="addAssignment()">Ata</button> <button class="btn ghost" onclick="closeModal()">İptal</button></div>`)
window.refreshAssignmentItems=()=>{const k=q("akind").value,items=k==="PDF Kaynak"?db.resources:db.exams;q("aitem").innerHTML=items.map(x=>`<option value="${x.id}">${x.title} — ${x.course} / ${x.topic}</option>`).join("")}
window.addAssignment=()=>{const kind=q("akind").value,items=kind==="PDF Kaynak"?db.resources:db.exams,item=items.find(x=>x.id===Number(q("aitem").value));if(!item)return alert("Atanabilir içerik yok");db.assignments.push({id:Date.now(),studentId:Number(q("astudent").value),kind,title:item.title,course:item.course,topic:item.topic,sourceId:item.id,status:"Bekliyor",assignedAt:new Date().toISOString().slice(0,10)});save();closeModal();assignments()}
window.completeAssignment=id=>{const a=db.assignments.find(x=>x.id===id);if(!a)return;modal(`<h2>Atamayı Tamamla</h2><p><b>${a.title}</b><br>${studentName(a.studentId)} — ${a.course} / ${a.topic}</p><div class="field"><label>Başarı %</label><input id="ascore" type="number" min="0" max="100"></div><div style="margin-top:16px"><button class="btn primary" onclick="saveAssignmentResult(${id})">Kaydet</button></div>`)}
window.saveAssignmentResult=id=>{const a=db.assignments.find(x=>x.id===id);if(!a)return;const score=Math.max(0,Math.min(100,Number(q("ascore").value)));a.status="Tamamlandı";a.completedAt=new Date().toISOString().slice(0,10);a.score=score;db.results.push({id:Date.now(),studentId:a.studentId,kind:a.kind==="PDF Kaynak"?"Ödev":"Online Sınav",course:a.course,topic:a.topic,score,date:a.completedAt,assignmentId:a.id});save();closeModal();assignments()}
function results(){
 shell(`<div class="toolbar"><h1>Başarı Girişi</h1><button class="btn primary" onclick="resultModal()">+ Sonuç Gir</button></div>
 <p class="muted">Tekrar eşiği: %${db.threshold}</p><table><thead><tr><th>Öğrenci</th><th>Tür</th><th>Konu</th><th>Başarı</th><th>Tarih</th></tr></thead><tbody>
 ${db.results.slice().reverse().map(r=>`<tr><td>${studentName(r.studentId)}</td><td>${r.kind}</td><td>${r.course} / ${r.topic}</td><td><span class="badge ${scoreClass(r.score)}">%${r.score}</span></td><td>${r.date}</td></tr>`).join("")}</tbody></table>`,"results")
}
window.resultModal=()=>modal(`<h2>Sonuç Gir</h2><div class="formgrid"><div class="field"><label>Öğrenci</label><select id="xstudent">${db.students.map(s=>`<option value="${s.id}">${s.name}</option>`).join("")}</select></div><div class="field"><label>Tür</label><select id="xkind"><option>Ödev</option><option>Online Sınav</option></select></div><div class="field"><label>Konu</label><select id="xtopic">${topicOptions()}</select></div><div class="field"><label>Başarı %</label><input id="xscore" type="number" min="0" max="100"></div></div><div style="margin-top:16px"><button class="btn primary" onclick="addResult()">Kaydet</button></div>`)
window.addResult=()=>{const [course,topic]=q("xtopic").value.split("|||"),score=Math.max(0,Math.min(100,Number(q("xscore").value)));db.results.push({id:Date.now(),studentId:Number(q("xstudent").value),kind:q("xkind").value,course,topic,score,date:new Date().toISOString().slice(0,10)});save();closeModal();results()}

let selectedStudentId=null;
function program(){
 if(!db.students.length){shell(`<h1>Haftalık Program</h1><div class="card">Önce öğrenci ekleyin.</div>`,"program");return}
 if(!selectedStudentId||!db.students.some(s=>s.id===selectedStudentId))selectedStudentId=db.students[0].id;
 const s=db.students.find(x=>x.id===selectedStudentId);
 const latest={};
 db.results.filter(r=>r.studentId===s.id).forEach(r=>{const k=r.course+"|||"+r.topic;if(!latest[k]||String(r.date)>=String(latest[k].date))latest[k]=r});
 const repeats=Object.values(latest).filter(r=>r.score<db.threshold);
 const rows=repeats.map(r=>{
   const wanted=s.levels?.[r.course]||"Orta";
   const res=db.resources.find(x=>x.course===r.course&&x.topic===r.topic&&x.level===wanted)||db.resources.find(x=>x.course===r.course&&x.topic===r.topic);
   const exam=db.exams.find(x=>x.course===r.course&&x.topic===r.topic);
   return `<tr><td><b>Tekrar</b></td><td>${r.course}</td><td>${r.topic}</td><td>${wanted}</td><td>${res?.title||"Uygun kaynak ekleyin"}</td><td>${exam?.title||"—"}</td><td><span class="badge low">Son başarı %${r.score}</span></td></tr>`
 }).join("");
 shell(`<div class="toolbar"><h1>Haftalık Program</h1><select onchange="selectedStudentId=Number(this.value);program()">${db.students.map(x=>`<option value="${x.id}" ${x.id===s.id?"selected":""}>${x.name}</option>`).join("")}</select></div>
 <p class="muted">Kural: son konu başarısı %${db.threshold} altındaysa konu sonraki haftaya tekrar taşınır. Kaynak seçerken öğrencinin ders için belirlenen zorluk seviyesi önceliklidir.</p>
 <table><thead><tr><th>Tür</th><th>Ders</th><th>Konu</th><th>Öğrenci seviyesi</th><th>PDF / Kaynak</th><th>Online Sınav</th><th>Neden</th></tr></thead><tbody>${rows||`<tr><td colspan="7">Tekrar gerektiren konu yok.</td></tr>`}</tbody></table>`,"program")
}
function q(id){return document.getElementById(id)}
function modal(html){const d=document.createElement("div");d.className="modalbg";d.id="modalbg";d.innerHTML=`<div class="modal">${html}</div>`;document.body.appendChild(d)}
window.closeModal=()=>document.getElementById("modalbg")?.remove()
window.resetDemo=()=>{db=structuredClone(seed);save();render()}
dashboard();
