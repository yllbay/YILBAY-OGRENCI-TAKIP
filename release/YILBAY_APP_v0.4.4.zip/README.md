# YILBAY Öğrenci Takip — v0.4.4

- Öğrenciye PDF kaynak atama
- Öğrenciye online sınav atama
- Atama durum takibi: Bekliyor / Tamamlandı
- Tamamlanan atamaya başarı yüzdesi girişi
- Atama sonucu otomatik olarak öğrenci sonuçlarına eklenir
- Başarı sonucu adaptif tekrar motorunu otomatik besler
- v0.4.3 yerel verisini otomatik taşır
