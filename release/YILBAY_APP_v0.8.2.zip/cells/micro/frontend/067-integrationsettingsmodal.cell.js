window.integrationSettingsModal=()=>modal(`<h2>API Ayarları</h2><p class="muted">Mevcut anahtarı korumak için alanı boş bırakabilirsiniz.</p><div class="formgrid">
 <div class="field"><label>OpenAI API Key</label><input id="openaiKey" type="password" autocomplete="off" placeholder="sk-..."></div>
 <div class="field"><label>OpenAI Modeli</label><select id="openaiModel"><option value="gpt-5.6-luna">GPT-5.6 Luna — düşük maliyet</option><option value="gpt-5.6-terra">GPT-5.6 Terra — daha yüksek kalite</option><option value="gpt-5.6-sol">GPT-5.6 Sol — en yüksek kalite</option></select></div>
 <div class="field" style="grid-column:1/-1"><label>YouTube Data API Key</label><input id="youtubeKey" type="password" autocomplete="off" placeholder="AIza..."></div>
 <div class="field"><label>USD/TL Maliyet Kuru</label><input id="usdTry" type="number" step="0.01" min="1" value="48.12"></div>
 <div class="field"><label>Aylık AI Bütçe Limiti (TL)</label><input id="monthlyBudgetTry" type="number" step="10" min="10" value="1000"></div>
 </div><div class="modal-actions"><button class="btn primary" onclick="saveIntegrationSettings()">Kaydet</button><button class="btn ghost" onclick="closeModal()">İptal</button></div>`)
