# YILBAY Öğrenci Takip — v0.4.0

Bu sürümde:
- Öğrenci kayıt ekranı
- Ders / ünite / alt ünite tanımlama
- PDF / kaynak havuzu
- Kaynak zorluk düzeyi
- Online sınav havuzu
- Başarı yüzdesi girişi
- Adaptif tekrar motoru (%70 altı konuyu sonraki haftaya taşır)

Not: Bu sürüm yerel MVP veri katmanı kullanır. Sonraki katmanda Supabase entegrasyonu yapılacaktır.
